<?php
//Database Configration
define('DB_USER', "arena");
define('DB_PASS', "arena123");
define('DB_DATA', "Arena");
define('DB_SERV', "localhost");
?>
