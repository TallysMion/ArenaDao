<?php

$response = array();

if(isset($_POST["login"]) && isset($_POST["senha"])){
	
	$login = $_POST["login"];
	$senha  = $_POST["senha"];
	
	
	require_once __DIR__ .'/db_connect.php';
	
	$db = new DB_CONNECT();
	
	$result = mysql_query("SELECT * FROM usuario WHERE login='$login' AND senha='$senha'");
	
	if(!empty($result)){
		if(mysql_num_rows($result) > 0){
			$result = mysql_fetch_array($result);
			$extid 				= $result["extid"];
			$usuario["id"]     	= $result["id"];
			$usuario["tipo"]   	= $result["tipo"];
			$usuario["extid"]   = $result["extid"];
			$usuario["arena"]   = $result["arena"];
			$usuario["nome"]   	= $result["nome"];
			$usuario["login"]   = $result["login"];
			$usuario["email"]   = $result["email"];
			$usuario["dataNasc"]= $result["dataNasc"];
			$usuario["telefone"]= $result["telefone"];
			
			if($result["tipo"] == 1){
				$result = mysql_query("SELECT * FROM teen WHERE id='$extid'");
				if(mysql_num_rows($result) > 0){
					$result = mysql_fetch_array($result);
					$usuario["ga"]     			= $result["ga"];
					$usuario["pontuacao"]     	= $result["pontuacao"];
					$usuario["appAberto"]     	= $result["appAberto"];		
					$response["success"] = 1;
					$response["usuario"] = $usuario;
					echo json_encode($response);						
				}else{
					$response["success"] = 0;
					$response["mensage"] = "Nenhum Teen Encontrado";
					echo json_encode($response);	
				}
			}else{
				$response["success"] = 1;
				$response["usuario"] = $usuario;
				echo json_encode($response);	
			}			
		}else{
			$response["success"] = 0;
			$response["mensage"] = "Nenhum usuario Encontrado";
			echo json_encode($response);			
		}
	}else{
		$response["success"] = 0;
		$response["mensage"] = "Nenhum usuario Encontrado";
		echo json_encode($response);			
	}
}else{
	$response["success"] = 0;
	$response["mensage"] = "Campo nao encontrado";
	echo json_encode($response);			
}


?>