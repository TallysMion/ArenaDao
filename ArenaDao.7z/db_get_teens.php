<?php

$response = array();

if(isset($_POST["ga"])){
	$ga = $_POST["ga"];
	require_once __DIR__ .'/db_connect.php';
	$db = new DB_CONNECT();
	$list = mysql_query("SELECT * FROM teen WHERE ga='$ga'");
	$result = array();
	if(!empty($list)){
		if(mysql_num_rows($list) > 0){
			while($teen = mysql_fetch_array($list)){
				$id = $teen["userId"];
				$usuario = mysql_query("SELECT * FROM usuario WHERE id='$id'");
				if(!empty($usuario)){
					$usuario = mysql_fetch_array($usuario);
					$item["id"] 		= $usuario["id"];
					$item["nome"] 		= $usuario["nome"];
					$item["pontuacao"] 	= $teen["pontuacao"];
					$result[] = $item;				
				}
			}
			$response["success"] = 1;
			$response["teens"] = $result;
			echo json_encode($response);	
		}else{
			$response["success"] = 0;
			$response["mensage"] = "Nenhum Teen Encontrado";
			echo json_encode($response);			
		}
	}else{
		$response["success"] = 0;
		$response["mensage"] = "Nenhum Teen Encontrado";
		echo json_encode($response);			
	}
}else{
	$response["success"] = 0;
	$response["mensage"] = "Campo nao encontrado";
	echo json_encode($response);			
}
?>