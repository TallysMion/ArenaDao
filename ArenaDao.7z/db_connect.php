<?php

class DB_CONNECT{
	
	//constructor
	function __construct(){
		$this->connect();
	}
	
	//destructor
	function __destruct(){
		$this->close();
	}
	
	//connecta
	function connect(){
		require_once __DIR__ .'/db_config.php';
		$con = mysql_connect(DB_SERV, DB_USER, DB_PASS) or die(mysql_error());
		$db = mysql_select_db(DB_DATA) or die(mysql_error()) or die(mysql_error());
		return $con;
	}
	
	function close(){
		mysql_close();
	}
	
}

?>