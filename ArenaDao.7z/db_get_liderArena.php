<?php

$response = array();

if(isset($_POST["id"])){
	$id = $_POST["id"];
	require_once __DIR__ .'/db_connect.php';
	$db = new DB_CONNECT();
	
	$result = mysql_query("SELECT * FROM ga WHERE lider='$id'");
	if(!empty($result)){
		if(mysql_num_rows($result) > 0){
			$result = mysql_fetch_array($result);
			$response["success"] = 1;
			$response["ga"] = $result["id"];
			echo json_encode($response);	
		}else{
			$response["success"] = 0;
			$response["mensage"] = "Nenhum ga Encontrado";
			echo json_encode($response);			
		}
	}else{
		$response["success"] = 0;
		$response["mensage"] = "Nenhum ga Encontrado";
		echo json_encode($response);			
	}
}else{
	$response["success"] = 0;
	$response["mensage"] = "Campo nao encontrado";
	echo json_encode($response);			
}
?>